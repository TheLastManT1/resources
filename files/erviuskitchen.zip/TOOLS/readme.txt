;this is a package.ini relative to the package inserted into.
[GUID]
;the guid name of the package (if omitted dsm_editor create new for package!)
86cd8488-74f8-4bbf-96c3-23519f9e4252
;(new_guid)
[Version]
;version of package:major.minor.QFELevel.build
1.2.3.4
[InterfaceGUID]
;the guidinterface name of the package (if omitted dsm_editor give it from guid name of package!)
86cd8488-74f8-4bbf-96c3-23519f9e4252
;(same_guid)
[InterfaceVersion]
;version of package:major.minor.QFELevel.build
4.3.2.1

[Shadows]
;all shadows to inser into dsm (not need they are present into dependences folder!)
86cd8488-74f8-4bbf-96c3-23519f9e4111
86cd8488-74f8-4bbf-96c3-23519f9e4222
86cd8488-74f8-4bbf-96c3-23519f9e4333

[Associations]
;all dependencies need to the package, need to be presetn into 'dependencies' folder becouse dsm editor has to read also relative dsm version!!!
86cd8488-74f8-4bbf-96c3-23519f9e4555
86cd8488-74f8-4bbf-96c3-23519f9e4666
86cd8488-74f8-4bbf-96c3-23519f9e4777
86cd8488-74f8-4bbf-96c3-23519f9e4888
86cd8488-74f8-4bbf-96c3-23519f9e4999

[Certifcates]
;all certificates need to insert into dsm, need they real exist into 'certificates' folder
x.cer
y.cer
z.cer
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

how to:
certificates and dependencies folder are subfolders of dsm_editor, they are collections of all dsm and certificates, shared at needed by all packages you want create.
package_sample is only an example and can be everywhere (if is into a folder that contains spaces, you need specify the dos pasameter with quotes: (dsm_editor - update "c:\documents and settings\package_sample")

parameters:
-update :needed to autoupdate from dos windo the follow package;
-Canonical optional, if you want build canonical (normal) package, then specify it in dos prompt, like a parameter, if omitted, dsm_editor build an "UPDATE" package (needed to build .pkg file!)

is a beta version, test it and report!!!
bye!
P.S.: supports old and new way packages( within \files and \lang\files format!)
