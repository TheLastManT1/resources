                                                                04/10/1999
  TascalRegEdit for Windows CE
    Version 0.50
  (C) Copyright 1997-1999, TascalSoft. All rights reserved.

                                                  tascal@msb.biglobe.ne.jp
                                       http://www2r.biglobe.ne.jp/~tascal/

1. GENERAL

  This is a registry editor program such as Windows 95 one. Make sure you
  can edit registries only on your own risk.


2. INSTALL

  + H/PC (Windows CE 1.0)
    Please copy the file 'TascalRegEdit.exe' to somewhere folder in your
    H/PC by H/PC Explorer.

  + H/PC (Windows CE 2.0)
    Please copy the file 'TascalRegEdit.exe' to somewhere folder in your
    H/PC by Windows CE Service.

  + P/PC (Windows CE 2.0)
    At first, Please copy the file 'TascalRegEdit.exe' to somewhere folder
    in your P/PC by Windows CE Service.
    Second, Make a shoftcut file in '\Windows\Start Menu'.
    
    You don't need make a short cut file if you use any of laucher program
    (example TascalExplorer P/PC).


3. UNINSTALL

  This version don't use registry. So, all of your work for uninstall is
  just removing the file 'TascalRegEdit.exe' from your H/PC.


4. FUNCTION

  Basic operations are same as standard Windows RegEdit. Sorry, now we 
  have no document about operations of this program.


5. RESTRICTIONS

  Current version don't support bellow functions. I want to support these
  in furture.

    + Find function is not support.
    + Editing buffer size is 8192 bytes.


6. HISTORIES

  04/10/1999 version 0.50
    + Add copy and paste function.

  02/11/1999 version 0.41
    + Change editting buffer size from 4092 to 8192 bytes.
    + Change internal processing (editting multi string).

  02/11/1999 version 0.40
    + Bug fix: Incorrect multi string accessing.
    + Bug fix: Incorrect binary editting.
    + Open a importting file from command line.
    + Add error message when you can't set value.
    + Add file extension (*.reg) when you export a file.

  09/20/1998 version 0.30
    + Bug fix: key is deleted when a user try to rename a key and use same
      name.
    + Support edit multi string value and binary data.

  07/07/1998 version 0.25
    + Press enter key to edit a value.
    + Show current selection.
    + Switch view by TAB key.
    + Bug fix: sometimes can't edit a value.
    + Change vertical sash position by screen size.

  06/07/1998 version 0.23
    + Bug fix: can't export registry key path correctry.
    + Path of registry key is displayed at status bar.

  05/11/1998 version 0.22
    + Bug fix: can't delete a key or rename a key with CE2.0.

  03/29/1998 version 0.21
    + Bug fix: error on refresh.

  03/20/1998 version 0.20
    + Support import/export registry keys to file.
    + Support add key function.
    + Support rename key function.
    + Bug fix: don't execute on english version H/PC.

  03/08/1998 version 0.10
    + First release version.

  The newest version of this program may be in our web site:
  <http://www2r.biglobe.ne.jp/~tascal/>.


7. AGREEMENT

  We have no warranty for any results of using this program.
  If you have any problem with this program, please contact us by e-mail.


8. NOTE

  If you have any questions or opinions, please send e-mail to us,
  tascal@msb.biglobe.ne.jp .
